import collections
import re
import urllib.request

URLS = {
    "https://www.gutenberg.org/cache/epub/14794/pg14794.txt",
    "https://www.gutenberg.org/cache/epub/35868/pg35868.txt",
    "https://gutenberg.org/cache/epub/16386/pg16386.txt",
    "https://www.gutenberg.org/cache/epub/16157/pg16157.txt",
    "https://www.gutenberg.org/cache/epub/17257/pg17257.txt",
    "https://www.gutenberg.org/cache/epub/15845/pg15845.txt",
    "https://www.gutenberg.org/cache/epub/15531/pg15531.txt",
    "https://gutenberg.org/cache/epub/17479/pg17479.txt",
    "https://www.gutenberg.org/cache/epub/18536/pg18536.txt",
    "https://www.gutenberg.org/cache/epub/16119/pg16119.txt",
    "https://www.gutenberg.org/cache/epub/13773/pg13773.txt",
    "https://www.gutenberg.org/cache/epub/16312/pg16312.txt",
    "https://www.gutenberg.org/cache/epub/15628/pg15628.txt",
    "https://www.gutenberg.org/files/43902/43902-0.txt",
    "https://www.gutenberg.org/cache/epub/13687/pg13687.txt",
    "https://www.gutenberg.org/cache/epub/17479/pg17479.txt",
    "https://www.gutenberg.org/cache/epub/18887/pg18887.txt",
    "https://www.gutenberg.org/files/46639/46639-0.txt",
    "https://www.gutenberg.org/cache/epub/17786/pg17786.txt",
    "https://www.gutenberg.org/cache/epub/13156/pg13156.txt",
    "https://www.gutenberg.org/cache/epub/13915/pg13915.txt",
    "https://www.gutenberg.org/cache/epub/13683/pg13683.txt",
    "https://www.gutenberg.org/cache/epub/15845/pg15845.txt",
    "https://www.gutenberg.org/cache/epub/15418/pg15418.txt",
    "https://www.gutenberg.org/cache/epub/18141/pg18141.txt",
    "https://www.gutenberg.org/cache/epub/18802/pg18802.txt",
    "https://www.gutenberg.org/cache/epub/20228/pg20228.txt",
    "https://www.gutenberg.org/files/45007/45007-0.txt",
    "https://www.gutenberg.org/cache/epub/13686/pg13686.txt"
}


def print_hi(name):
    print(f'Hi, {name}')  # Press ⌘F8 to toggle the breakpoint.


if __name__ == '__main__':
    print("¡Welcome to TAGALOG CORPUS BUILDER!\n")
    corpus = []
    i = 1
    for url in URLS:
        print(f"downloading: {url}... ({i} out of {len(URLS)})")
        i += 1
        text = urllib.request.urlopen(url).read().decode("utf-8")
        corpus.extend(re.sub('([.,¡!?¿()])', r' \1 ', text).split())

    print("Corpus overall length:", len(corpus))
    print("Most common words and their freq.:", collections.Counter(corpus).most_common(50))
    with open("my_corpus.txt","w",encoding="utf-8") as outfile:
        print(" ".join(corpus),file=outfile)
    print("Corpus printed into my_corpus.txt")
